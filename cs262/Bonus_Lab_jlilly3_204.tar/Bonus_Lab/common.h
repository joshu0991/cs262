#include <stdio.h>

typedef struct _FileData
{
    int a;
    double b;
    char dataStr[60];
} FileData;

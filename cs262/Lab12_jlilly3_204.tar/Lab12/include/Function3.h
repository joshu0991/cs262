#ifndef FUNCTION3_H
#define FUNCTION3_H

void Function3();

#endif

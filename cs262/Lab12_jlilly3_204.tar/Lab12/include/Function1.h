#ifndef FUNCTION1_H
#define FUNCTION1_H

void Function1();

#endif 

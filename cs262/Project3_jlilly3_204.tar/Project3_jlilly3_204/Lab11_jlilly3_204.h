

void setlsbs(unsigned char *p, unsigned char b0);
unsigned char getlsbs(unsigned char *p);
void print_decimal(unsigned char* p);
void print_bin(unsigned char* p);
